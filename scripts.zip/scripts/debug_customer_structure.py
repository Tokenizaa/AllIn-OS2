#!/usr/bin/env python3
"""
Script para mapear a estrutura da página de customers
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from scrape.auth import LojaVirtualAuth
from bs4 import BeautifulSoup

# Autenticar
auth = LojaVirtualAuth()
if not auth.login():
    print("❌ Falha na autenticação")
    sys.exit(1)

session = auth.get_session()
token = auth.token
loja_base_url = auth.loja_base_url

# Acessar página de customer
customer_id = "2628"
url = f"{loja_base_url}/sale/customer/info?token={token}&customer_id={customer_id}"

print(f"🔍 Acessando: {url}")
response = session.get(url)

if response.status_code != 200:
    print(f"❌ Erro: {response.status_code}")
    sys.exit(1)

soup = BeautifulSoup(response.text, 'html.parser')

# Salvar HTML para análise
with open('customer_page.html', 'w', encoding='utf-8') as f:
    f.write(response.text)

print("✅ HTML salvo em customer_page.html")

# Tentar encontrar elementos com diferentes seletores
print("\n🔍 Buscando elementos...")

# Buscar por labels
labels = soup.find_all(['label', 'span', 'div'], string=lambda x: x and any(keyword in x.lower() for keyword in ['usuário', 'nome', 'email', 'telefone', 'cpf', 'cnpj', 'patrocinador', 'plano']))

for label in labels[:20]:
    print(f"Label: {label.get_text(strip=True)[:50]}")
    # Buscar próximo input ou elemento irmão
    next_elem = label.find_next(['input', 'div', 'span'])
    if next_elem:
        print(f"  Próximo: {next_elem.name} - {next_elem.get('value', next_elem.get_text(strip=True)[:50] if next_elem.name != 'input' else next_elem.get('value', ''))[:50]}")

print("\n✅ Análise concluída")
