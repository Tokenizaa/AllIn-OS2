"""Utils para scraping"""
