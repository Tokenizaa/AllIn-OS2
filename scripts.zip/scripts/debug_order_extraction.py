#!/usr/bin/env python3
"""
Script para debug da extração de dados de pedido
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from scrape.auth import LojaVirtualAuth
from scrape.extractors import OrdersExtractor
from scrape.transformers import SupabaseTransformer

# Autenticar
auth = LojaVirtualAuth()
if not auth.login():
    print("❌ Falha na autenticação")
    sys.exit(1)

session = auth.get_session()
token = auth.token
loja_base_url = auth.loja_base_url

# Extrair um pedido
extractor = OrdersExtractor(session, loja_base_url, token)
order_id = "25091"
pedido = extractor.extract_order_details(order_id)

if not pedido:
    print("❌ Erro ao extrair pedido")
    sys.exit(1)

print("📋 PedidoInfo:")
print(f"  ID: {pedido.pedido.id}")
print(f"  Cliente ID: {pedido.pedido.cliente_id}")
print(f"  Cliente: {pedido.pedido.cliente}")
print(f"  Email: {pedido.pedido.email}")
print(f"  Telefone: {pedido.pedido.telefone}")
print(f"  CNPJ: {pedido.pedido.cnpj}")
print(f"  Patrocinador Usuario: {pedido.pedido.patrocinador_usuario}")
print(f"  Patrocinador Nome: {pedido.pedido.patrocinador_nome}")
print(f"  Tipo Cliente: {pedido.pedido.tipo_cliente}")

print("\n📋 DistribuidorInfo:")
if pedido.distribuidor:
    print(f"  Nome: {pedido.distribuidor.nome}")
    print(f"  Patrocinador Usuario: {pedido.distribuidor.patrocinador_usuario}")
    print(f"  Patrocinador Nome: {pedido.distribuidor.patrocinador_nome}")
    print(f"  Email: {pedido.distribuidor.email}")
    print(f"  Endereço: {pedido.distribuidor.endereco}")
    print(f"  Cidade: {pedido.distribuidor.cidade}")
    print(f"  CNPJ: {pedido.distribuidor.cnpj}")
    print(f"  Nome Fantasia: {pedido.distribuidor.nome_fantasia}")
else:
    print("  DistribuidorInfo é None")

print("\n📋 PagadorInfo:")
if pedido.pagador:
    print(f"  Nome: {pedido.pagador.nome}")
    print(f"  Sobrenome: {pedido.pagador.sobrenome}")
    print(f"  Endereço: {pedido.pagador.endereco}")
    print(f"  Cidade: {pedido.pagador.cidade}")
    print(f"  Estado: {pedido.pagador.estado}")
    print(f"  Bairro: {pedido.pagador.bairro}")
    print(f"  Numero: {pedido.pagador.numero}")
    print(f"  CEP: {pedido.pagador.cep}")
else:
    print("  PagadorInfo é None")

print("\n📋 EnvioInfo:")
if pedido.envio:
    print(f"  Nome: {pedido.envio.nome}")
    print(f"  Endereço: {pedido.envio.endereco}")
    print(f"  Cidade: {pedido.envio.cidade}")
    print(f"  Estado: {pedido.envio.estado}")
    print(f"  Bairro: {pedido.envio.bairro}")
    print(f"  Numero: {pedido.envio.numero}")
    print(f"  CEP: {pedido.envio.cep}")
else:
    print("  EnvioInfo é None")
