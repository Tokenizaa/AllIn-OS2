#!/usr/bin/env python3
"""
Script para salvar HTML da página de pedido para análise
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from scrape.auth import LojaVirtualAuth
import requests

# Autenticar
auth = LojaVirtualAuth()
if not auth.login():
    print("❌ Falha na autenticação")
    sys.exit(1)

session = auth.get_session()
token = auth.token
loja_base_url = auth.loja_base_url

# Acessar página de pedido
order_id = "25091"
url = f"{loja_base_url}/sale/order/info?token={token}&order_id={order_id}"

print(f"🔍 Acessando: {url}")
response = session.get(url)

if response.status_code != 200:
    print(f"❌ Erro: {response.status_code}")
    sys.exit(1)

# Salvar HTML
with open('order_page.html', 'w', encoding='utf-8') as f:
    f.write(response.text)

print("✅ HTML salvo em order_page.html")
