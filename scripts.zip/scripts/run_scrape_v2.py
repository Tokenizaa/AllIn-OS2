#!/usr/bin/env python3
"""
Script principal para execução do scrape completo da loja virtual AllInBrasil
Versão 2.0 - Arquitetura robusta com batch processing, checkpoints e monitoramento

Melhorias implementadas:
- Batch processing (BATCH_SIZE = 100)
- Checkpoints para recuperação após falha
- Logging estruturado
- Monitoramento em tempo real
- UPSERT otimizado em lote
- Retry com backoff exponencial
- Validação de integridade
"""

import os
import sys
import time
from datetime import datetime
from dotenv import load_dotenv

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Adicionar diretório scripts ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from scrape.auth import LojaVirtualAuth
from scrape.extractors import OrdersExtractor
from scrape.transformers import SupabaseTransformer
from scrape.loaders.supabase_loader_v2 import SupabaseLoaderV2
from scrape.utils.logger import get_logger
from scrape.utils.monitoring import ScrapeMonitor
from scrape.utils.checkpoint import CheckpointManager

# Configurações
SUPABASE_URL = os.getenv('SUPABASE_URL', 'https://isjsydhuqurneswstlyx.supabase.co')
SUPABASE_KEY = os.getenv('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...')
LOJA_VIRTUAL_BASE_URL = "https://allinbrasil.com.br/loja/admin"
BATCH_SIZE = 100  # Processar e persistir a cada 100 pedidos


def main():
    print("🚀 Iniciando scrape completo da loja virtual AllInBrasil v2.0")
    print(f"📅 Data/Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🌐 URL Supabase: {SUPABASE_URL}")
    print(f"🌐 URL Loja Virtual: {LOJA_VIRTUAL_BASE_URL}")
    print(f"📦 Batch Size: {BATCH_SIZE}")
    print("-" * 60)
    
    # Inicializar logger
    logger = get_logger()
    logger.info("Iniciando scrape v2.0", module='main')
    
    # Inicializar checkpoint manager
    checkpoint_manager = CheckpointManager()
    
    # Verificar se existe checkpoint para retomar
    if checkpoint_manager.can_resume():
        logger.info("Checkpoint encontrado. Pode retomar do último pedido processado.", module='main')
        checkpoint_manager.print_status()
        resume_from = checkpoint_manager.get_resume_from_order()
        logger.info(f"Retomando do pedido: {resume_from}", module='main')
    else:
        logger.info("Nenhum checkpoint encontrado. Iniciando do zero.", module='main')
        resume_from = None
    
    # 1. Autenticar na loja virtual
    print("\n🔐 FASE 1: Autenticação")
    logger.info("Iniciando autenticação", module='auth')
    
    auth = LojaVirtualAuth()
    if not auth.login():
        logger.error("Falha na autenticação", module='auth')
        print("❌ Falha na autenticação. Abortando.")
        return
    
    session = auth.get_session()
    token = auth.token
    loja_base_url = auth.loja_base_url
    
    if not token or not loja_base_url:
        logger.error("Token ou URL base da loja não encontrados", module='auth')
        print("❌ Token ou URL base da loja não encontrados. Abortando.")
        return
    
    logger.info("Autenticação bem-sucedida", module='auth')
    
    # 2. Extrair lista de pedidos
    print("\n📋 FASE 2: Extração de lista de pedidos")
    logger.info("Iniciando extração de lista de pedidos", module='pagination')
    
    extractor = OrdersExtractor(session, loja_base_url, token)
    orders = extractor.extract_orders_list()
    
    if not orders:
        logger.warning("Nenhum pedido encontrado", module='pagination')
        print("⚠️ Nenhum pedido encontrado.")
        return
    
    print(f"\n📊 {len(orders)} pedidos encontrados")
    logger.info(f"{len(orders)} pedidos encontrados", module='pagination')
    
    # Se retomando, encontrar índice do pedido para retomar
    start_index = 0
    if resume_from:
        try:
            start_index = orders.index(resume_from)
            logger.info(f"Retomando do índice {start_index} (pedido {resume_from})", module='main')
            print(f"📍 Retomando do pedido {resume_from} (índice {start_index})")
        except ValueError:
            logger.warning(f"Pedido {resume_from} não encontrado na lista. Iniciando do zero.", module='main')
            print(f"⚠️ Pedido {resume_from} não encontrado. Iniciando do zero.")
    
    # 3. Inicializar componentes
    print("\n🔧 FASE 3: Inicialização de componentes")
    logger.info("Inicializando componentes", module='main')
    
    transformer = SupabaseTransformer(SUPABASE_URL, SUPABASE_KEY)
    loader = SupabaseLoaderV2(SUPABASE_URL, SUPABASE_KEY)
    monitor = ScrapeMonitor(total_orders=len(orders))
    
    # 4. Processar pedidos em batches
    print("\n🔄 FASE 4: Processamento em batches")
    logger.info(f"Iniciando processamento em batches de {BATCH_SIZE}", module='main')
    
    batch_customers = {}
    batch_orders = []
    batch_order_items = []
    
    total_customers_created = checkpoint_manager.get_checkpoint()['customers_processados']
    total_orders_created = checkpoint_manager.get_checkpoint()['orders_processados']
    total_order_items_created = checkpoint_manager.get_checkpoint()['order_items_processados']
    total_errors = checkpoint_manager.get_checkpoint()['erros']
    
    for i in range(start_index, len(orders)):
        order_id = orders[i]
        
        try:
            # Extrair detalhes do pedido
            logger.info(f"Extraindo pedido {order_id}", module='extraction', order_id=order_id)
            complete_order = extractor.extract_order_details(order_id)
            
            if not complete_order:
                logger.warning(f"Pedido {order_id} não encontrado ou erro na extração", module='extraction', order_id=order_id)
                monitor.increment_errors()
                total_errors += 1
                continue
            
            # Transformar customer
            customer = transformer.transform_customer_from_order(complete_order)
            if customer and customer['id_comprador']:
                batch_customers[customer['id_comprador']] = customer
            
            # Transformar order
            order = transformer.transform_order(complete_order)
            batch_orders.append(order)
            
            # Transformar order items
            order_items = transformer.transform_order_items(complete_order)
            batch_order_items.extend(order_items)
            
            # Atualizar monitor
            monitor.update_progress()
            
            # Rate limiting
            time.sleep(1)
            
            # Pausa a cada 50 pedidos para evitar sobrecarga
            if (i - start_index + 1) % 50 == 0:
                logger.info(f"Pausa de 10 segundos após {i - start_index + 1} pedidos", module='rate_limit')
                print(f"\n⏸️ Pausa de 10 segundos após {i - start_index + 1} pedidos...")
                time.sleep(10)
            
            # Persistir batch ao atingir BATCH_SIZE
            if len(batch_orders) >= BATCH_SIZE or i == len(orders) - 1:
                logger.info(
                    f"Persistindo batch: {len(batch_orders)} orders, {len(batch_customers)} customers, {len(batch_order_items)} items",
                    module='batch_persistence'
                )
                print(f"\n💾 Persistindo batch de {len(batch_orders)} pedidos...")
                
                # Persistir customers
                if batch_customers:
                    customers_data = list(batch_customers.values())
                    updated, created = loader.upsert_customers_batch(customers_data)
                    total_customers_created += len(customers_data)
                    monitor.increment_customers(len(customers_data))
                    logger.info(f"Customers persistidos: {len(customers_data)}", module='persistence')
                    print(f"✅ {len(customers_data)} customers persistidos")
                    batch_customers.clear()
                
                # Persistir orders
                if batch_orders:
                    updated, created = loader.upsert_orders_batch(batch_orders)
                    total_orders_created += len(batch_orders)
                    monitor.increment_orders(len(batch_orders))
                    logger.info(f"Orders persistidas: {len(batch_orders)}", module='persistence')
                    print(f"✅ {len(batch_orders)} orders persistidas")
                    batch_orders.clear()
                
                # Persistir order items
                if batch_order_items:
                    items_count = loader.upsert_order_items_batch(batch_order_items)
                    total_order_items_created += items_count
                    monitor.increment_order_items(items_count)
                    logger.info(f"Order items persistidos: {items_count}", module='persistence')
                    print(f"✅ {items_count} order_items persistidos")
                    batch_order_items.clear()
                
                # Salvar checkpoint
                checkpoint_manager.save_checkpoint(
                    ultimo_pedido=order_id,
                    pedidos_processados=i + 1,
                    customers_processados=total_customers_created,
                    orders_processados=total_orders_created,
                    order_items_processados=total_order_items_created,
                    erros=total_errors,
                    status='in_progress'
                )
                logger.info(f"Checkpoint salvo: pedido {order_id}", module='checkpoint')
                
                # Imprimir status
                monitor.print_status()
                
        except Exception as e:
            logger.error(f"Erro ao processar pedido {order_id}: {e}", module='processing', order_id=order_id, exc_info=True)
            monitor.increment_errors()
            total_errors += 1
            print(f"❌ Erro ao processar pedido {order_id}: {e}")
            continue
    
    # 5. Finalizar
    print("\n🎉 FASE 5: Finalização")
    logger.info("Finalizando scrape", module='main')
    
    # Marcar checkpoint como completed
    checkpoint_manager.mark_completed()
    logger.info("Checkpoint marcado como completed", module='checkpoint')
    
    # Imprimir status final
    monitor.print_status()
    
    print("\n📊 RESUMO FINAL:")
    print(f"✅ Pedidos processados: {monitor.orders_processed} / {monitor.total_orders}")
    print(f"✅ Customers criados: {total_customers_created}")
    print(f"✅ Orders criadas: {total_orders_created}")
    print(f"✅ Order items criados: {total_order_items_created}")
    print(f"❌ Erros: {total_errors}")
    print(f"⏱️ Tempo total: {monitor.get_elapsed_time()}")
    
    logger.info(
        f"Scrape finalizado: {monitor.orders_processed} pedidos, {total_customers_created} customers, {total_orders_created} orders, {total_order_items_created} items, {total_errors} erros",
        module='main'
    )
    
    print("\n🎉 Scrape finalizado com sucesso!")


if __name__ == '__main__':
    main()
